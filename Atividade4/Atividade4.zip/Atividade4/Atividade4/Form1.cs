﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class FrmSalario : Form
    {
        public FrmSalario()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }

        private void btnVerificaDesconto_Click(object sender, EventArgs e)
        {
            double descontoINSS = 0;
            double descontoIRPF = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;
            double salarioFamilia = 0;
            double numeroFilhos = 0;

            if(txtNomeFunc.Text == string.Empty)
            {
                MessageBox.Show("O nome do funcionario" + "\n" +
                    "nao pode ser vazio");
            }
            else
            {
                if(!double.TryParse(mskbxSalBruto.Text, out salarioBruto) || !double.TryParse(mskbxNumFilhos.Text, out salarioFamilia))
                {
                    MessageBox.Show("Salario Bruto e o numero de filhos devem ser numericos");
                }
                else 
                {
                    if (salarioBruto <= 0)
                        MessageBox.Show("Salario Bruto deve ser maior que 0");
                    else
                    {
                        //Calculo para INSS
                        if (salarioBruto <= 800.47)
                        {
                           mskbxAliqInss.Text = "7,65%";
                           descontoINSS = 0.765 * salarioBruto;

                        }
                        else if (salarioBruto <= 1050)
                        {
                            mskbxAliqInss.Text = "9,65%";
                            descontoINSS = ((8.65 / 100) * salarioBruto);


                        }
                        else if(salarioBruto <= 1400.77)
                        {
                            mskbxAliqInss.Text = "9,00%";
                            descontoINSS = ((9 / 100) * salarioBruto);


                        }
                        else if (salarioBruto <= 2801.56)
                        {
                            mskbxAliqInss.Text = "11,00%";
                            descontoINSS = ((11 / 100) * salarioBruto);


                        }
                        else
                        {
                            mskbxAliqInss.Text = "teto";
                            descontoINSS = 308.17;
                        }

                        mskbxDescontoInss.Text = descontoINSS.ToString("N2");


                        // Desconto Imposto de Renda

                        if (salarioBruto <= 1257.12)
                            mskbxAliqIRPF.Text = "0";
                        else if(salarioBruto <= 2512.08)
                        {
                            mskbxAliqIRPF.Text = "15%";
                            descontoIRPF = (salarioBruto*(15/100));
                        }
                        else
                        {
                            mskbxAliqIRPF.Text = "27,5%";
                            descontoIRPF = (salarioBruto * (27.5 / 100));
                        }

                        mskbxDescontoIRPF.Text = descontoIRPF.ToString("N2");

                        //Salario Familia
                        if(numeroFilhos > 0)
                        {
                            if (salarioBruto <= 435.52)
                                salarioFamilia = (22.33 * numeroFilhos);
                            else if (salarioBruto <= 654.61)
                                salarioFamilia = (15.74 * numeroFilhos);
                            else
                                salarioFamilia = 0;
                        }

                        salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                        mskbxSalarioFamilia.Text = salarioFamilia.ToString("N2");
                        mskbxSalarioLiquido.Text = salarioLiquido.ToString("N2");

                        // = se(condicao;AAA;BBB)
                        // = condicao ? vlr se verdadeiro : vlr se falso;

                        lblDados.Text = " Os descontos do salario " +
                            (rbtnFeminino.Checked ? "da Sra." : "do Sr.") + txtNomeFunc.Text + "\n"+ " que e " +
                            (ckbxCasado.Checked ? "Casado(a)" : "Solteiro(a)") + "\n" + " e que tem " +
                            Convert.ToString(salarioFamilia) + " filhos(s) sao:";

                    }











                }
            }






        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void mskbxNumFilhos_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
