﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnConta1_Click(object sender, EventArgs e)
        {
            int EBrancos = 0;

            if (rchtxtFrase.Text.Length <= 100) // valida se a frase inserida e menor do que 100 caracteres
            {
                foreach (char b in rchtxtFrase.Text)
                {
                    if (char.IsWhiteSpace(b))
                        EBrancos++;
                }
                MessageBox.Show("Espaços em brancos: " + EBrancos);
            }
            else
                MessageBox.Show("Limte de 100 letras");

        }

        private void btnConta2_Click(object sender, EventArgs e)
        {
            int cont = 0;

            if (rchtxtFrase.Text.Length <= 100)
            {

                for (int i = 0; i < rchtxtFrase.Text.Length; i++)
                {
                    if (rchtxtFrase.Text[i] == 'r')
                        cont++;
                }
                MessageBox.Show("Numero de Rs: " + cont);
            }
            else
                MessageBox.Show("Limte de 100 letras");

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnContaPares_Click(object sender, EventArgs e)
        {
            int cont = 0;

            if (rchtxtFrase.Text.Length <= 100)
            {
                for (int i = 0; i < rchtxtFrase.Text.Length - 1; i++)
                {
                    if (rchtxtFrase.Text[i] == rchtxtFrase.Text[i + 1])
                        cont++;
                }

                MessageBox.Show("Quantidade de ocorrencia de pares: " + cont);
            }
            else
                MessageBox.Show("Limte de 100 letras");
        }
    }
}
