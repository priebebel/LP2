﻿namespace Atividade6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnConta1 = new System.Windows.Forms.Button();
            this.btnContaR = new System.Windows.Forms.Button();
            this.btnContaPares = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(189, 37);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(385, 188);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnConta1
            // 
            this.btnConta1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConta1.Location = new System.Drawing.Point(119, 273);
            this.btnConta1.Name = "btnConta1";
            this.btnConta1.Size = new System.Drawing.Size(111, 61);
            this.btnConta1.TabIndex = 1;
            this.btnConta1.Text = "Conta espaços em Branco";
            this.btnConta1.UseVisualStyleBackColor = true;
            this.btnConta1.Click += new System.EventHandler(this.btnConta1_Click);
            // 
            // btnContaR
            // 
            this.btnContaR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaR.Location = new System.Drawing.Point(315, 273);
            this.btnContaR.Name = "btnContaR";
            this.btnContaR.Size = new System.Drawing.Size(111, 61);
            this.btnContaR.TabIndex = 2;
            this.btnContaR.Text = "Conta Letras R";
            this.btnContaR.UseVisualStyleBackColor = true;
            this.btnContaR.Click += new System.EventHandler(this.btnConta2_Click);
            // 
            // btnContaPares
            // 
            this.btnContaPares.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaPares.Location = new System.Drawing.Point(527, 273);
            this.btnContaPares.Name = "btnContaPares";
            this.btnContaPares.Size = new System.Drawing.Size(111, 61);
            this.btnContaPares.TabIndex = 3;
            this.btnContaPares.Text = "Conta Pares de Letras";
            this.btnContaPares.UseVisualStyleBackColor = true;
            this.btnContaPares.Click += new System.EventHandler(this.btnContaPares_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContaPares);
            this.Controls.Add(this.btnContaR);
            this.Controls.Add(this.btnConta1);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "Form2";
            this.Text = "Exercicio 1";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnConta1;
        private System.Windows.Forms.Button btnContaR;
        private System.Windows.Forms.Button btnContaPares;
    }
}