﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            
            {
                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string texto = txtPalin.Text;
            string s = "";

            if (txtPalin.Text.Length <= 50)
            {
                for (int x = 0; x < texto.Length; x++)
                {
                    if (char.IsWhiteSpace(texto[x]))
                        texto = texto.Remove(x, 1);
                }

                char[] frase2 = texto.ToCharArray();
                Array.Reverse(frase2);

                foreach (char c in frase2)
                    s = s + c.ToString();

                if (s == texto)
                    MessageBox.Show("É um palíndromo");
                else
                    MessageBox.Show("Não é palíndromo");
            }
            else
                MessageBox.Show("Limite máximo de 50 letras");
        }
    }
}
