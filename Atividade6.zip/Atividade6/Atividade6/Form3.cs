﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
                double soma = 0;
                int n = Convert.ToInt32(txtNum.Text);

                for (int i = 1; i <= n; i++)
                {
                    soma = soma + (1 / Convert.ToDouble(i));
                }

                MessageBox.Show("H = " + soma.ToString("N2"));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex);
            }
        }
    }
}
