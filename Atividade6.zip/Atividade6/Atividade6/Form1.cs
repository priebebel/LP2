﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 novo = new Form2();

            novo.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                Form4 novo = new Form4();

                novo.Show();
            }
        }

        private void btnExe2_Click(object sender, EventArgs e)
        {
            {
                Form3 novo = new Form3();

                novo.Show();
            }
        }

        private void btnExe4_Click(object sender, EventArgs e)
        {
            {
                Form5 novo = new Form5();

                novo.Show();
            }
        }
    }
}
