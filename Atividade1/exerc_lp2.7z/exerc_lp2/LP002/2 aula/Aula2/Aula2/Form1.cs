﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")//if textBox1.Text==String.Empty
                MessageBox.Show("Nome Vazio!!!");
            else
                MessageBox.Show(textBox1.Text, "Informação", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            if (comboBox1.SelectedIndex == -1)
                MessageBox.Show("Você não escolheu o curso!");
            else
                MessageBox.Show("Curso:" + comboBox1.SelectedItem.ToString());
            if (listBox1.SelectedIndex == -1)
                MessageBox.Show("Não escolheu o Semestre!!");
            else
                MessageBox.Show("Semestre:" + listBox1.SelectedItem.ToString());
            //if (checkBox1.Checked)
            //    MessageBox.Show("E casado");
            //else
            //    MessageBox.Show("Nao e casado");
            if (checkBox1.CheckState == CheckState.Checked)
                MessageBox.Show("E casado!");
            else
                if (checkBox1.CheckState == CheckState.Unchecked)
                    MessageBox.Show("Nao e casado!");
                else
                    MessageBox.Show("INDETERMINADO");
            if (radioButton1.Checked)
                MessageBox.Show("Escolheu feminino");
            else
                MessageBox.Show("Escolheu masculino");

            for (var x=0; x<=checkedListBox1.SelectedItems.Count - 1;x++)//e o totalzao selecionado
                MessageBox.Show("Selecionado" + checkedListBox1.SelectedItems[x].ToString());//e so um
            for (var x=0; x<=checkedListBox1.SelectedItems.Count - 1;x++)//e o totalzao selecionado
                MessageBox.Show("Checado" + checkedListBox1.CheckedItems[x].ToString());//e so um
            
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("1ºSemestre");
            listBox1.Items.Add("2ºSemestre");
            listBox1.Items.Add("3ºSemestre");
            listBox1.Items.Add("4ºSemestre");
            listBox1.Items.Add("5ºSemestre");
            listBox1.Items.Add("6ºSemestre");
            listBox1.Items.Add("7ºSemestre");
            listBox1.Items.Add("8ºSemestre");
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}
