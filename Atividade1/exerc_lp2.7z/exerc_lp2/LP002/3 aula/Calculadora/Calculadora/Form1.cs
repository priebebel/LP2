﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double verify1, verify2;
            if ((double.TryParse(txtNum1.Text, out verify1) &&
                double.TryParse(txtNum2.Text, out verify2)))
            {
                double sub = verify1 - verify2;
                txtNum3.Text = sub.ToString("N2");
            }
            else
                MessageBox.Show("Dados Invalidos");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                double verify1, verify2;
                if ((double.TryParse(txtNum1.Text, out verify1) &&
                    double.TryParse(txtNum2.Text, out verify2)))
                {
                    double mult = verify1 * verify2;
                    txtNum3.Text = mult.ToString("N2");
                }
                else
                    MessageBox.Show("Dados Invalidos");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Clear();
            txtNum3.Text = String.Empty;//ou txtNum3.Text =null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double verify1, verify2;
            if ((double.TryParse(txtNum1.Text, out verify1) &&
                double.TryParse(txtNum2.Text, out verify2)))
            {
                double soma = verify1 + verify2;
                txtNum3.Text = soma.ToString("N2");
            }
            else
                MessageBox.Show("Dados Invalidos");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            {
                double verify1, verify2;
                if ((double.TryParse(txtNum1.Text, out verify1) &&
                    double.TryParse(txtNum2.Text, out verify2)))
                    if (verify2 == 0)
                        MessageBox.Show("Divisor nao pode ser igual a zero!");
                    else
                {
                    double div = verify1 / verify2;
                    txtNum3.Text = div.ToString("N2");
                }
                else
                    MessageBox.Show("Dados Invalidos");
            }
        }
    }
}
