﻿namespace Peso_Ideal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Genero = new System.Windows.Forms.GroupBox();
            this.txtPesoAtual = new System.Windows.Forms.TextBox();
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rbtnMulher = new System.Windows.Forms.RadioButton();
            this.rdbtnHomem = new System.Windows.Forms.RadioButton();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.Genero.SuspendLayout();
            this.SuspendLayout();
            // 
            // Genero
            // 
            this.Genero.Controls.Add(this.rdbtnHomem);
            this.Genero.Controls.Add(this.rbtnMulher);
            this.Genero.Location = new System.Drawing.Point(551, 29);
            this.Genero.Name = "Genero";
            this.Genero.Size = new System.Drawing.Size(200, 100);
            this.Genero.TabIndex = 0;
            this.Genero.TabStop = false;
            this.Genero.Text = "Genero";
            this.Genero.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtPesoAtual
            // 
            this.txtPesoAtual.Location = new System.Drawing.Point(134, 46);
            this.txtPesoAtual.Name = "txtPesoAtual";
            this.txtPesoAtual.Size = new System.Drawing.Size(100, 20);
            this.txtPesoAtual.TabIndex = 1;
            // 
            // txtAltura
            // 
            this.txtAltura.Location = new System.Drawing.Point(134, 95);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(100, 20);
            this.txtAltura.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Peso Atual";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Altura";
            // 
            // rbtnMulher
            // 
            this.rbtnMulher.AutoSize = true;
            this.rbtnMulher.Checked = true;
            this.rbtnMulher.Location = new System.Drawing.Point(7, 23);
            this.rbtnMulher.Name = "rbtnMulher";
            this.rbtnMulher.Size = new System.Drawing.Size(57, 17);
            this.rbtnMulher.TabIndex = 0;
            this.rbtnMulher.TabStop = true;
            this.rbtnMulher.Text = "Mulher";
            this.rbtnMulher.UseVisualStyleBackColor = true;
            this.rbtnMulher.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rdbtnHomem
            // 
            this.rdbtnHomem.AutoSize = true;
            this.rdbtnHomem.Location = new System.Drawing.Point(7, 56);
            this.rdbtnHomem.Name = "rdbtnHomem";
            this.rdbtnHomem.Size = new System.Drawing.Size(61, 17);
            this.rdbtnHomem.TabIndex = 5;
            this.rdbtnHomem.Text = "Homem";
            this.rdbtnHomem.UseVisualStyleBackColor = true;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(313, 291);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(133, 85);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAltura);
            this.Controls.Add(this.txtPesoAtual);
            this.Controls.Add(this.Genero);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Genero.ResumeLayout(false);
            this.Genero.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox Genero;
        private System.Windows.Forms.TextBox txtPesoAtual;
        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rdbtnHomem;
        private System.Windows.Forms.RadioButton rbtnMulher;
        private System.Windows.Forms.Button btnCalcular;
    }
}

