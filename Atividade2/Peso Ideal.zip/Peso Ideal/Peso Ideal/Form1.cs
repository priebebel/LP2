﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Peso_Ideal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double altura, pesoatual;
            double DlPesoIdeal;

            if (double.TryParse(txtAltura.Text, out altura) &&
                double.TryParse(txtPesoAtual.Text, out pesoatual))
            {
                if(rbtnMulher.Checked)
                    {
                        DlPesoIdeal = (62.1 * altura) - 44.7;
                    }
                else
                    {
                        DlPesoIdeal = (72.7 * altura) - 58;
                    }
                //arredondando com 2 casas

                DlPesoIdeal = Math.Round(DlPesoIdeal, 2);

                if (pesoatual < DlPesoIdeal)
                {
                    MessageBox.Show("Pode comer a vontade");

                }
                else if(pesoatual==DlPesoIdeal)
                {
                    MessageBox.Show("Esta com o peso ideal");
                }
                else
                {
                    MessageBox.Show("Precisa controlar");
                }

            }
        }
    }
}
