﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class frm_exercicio2 : Form
    {
        public frm_exercicio2()
        {
            InitializeComponent();
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            
            if (String.Compare(txtPalavra1.Text, txtPalavra2.Text, true) == 0)
                MessageBox.Show("Sao iguais");
            else
                MessageBox.Show("Sao diferentes");
        }

        private void btnInsere_Click(object sender, EventArgs e)
        {
             // casa - meio = 2
            // fatec - meio = 2
            // sorocaba - meio = 4
            // txtPalavra1.text = a
            int meio = txtPalavra2.Text.Length / 2;
            txtPalavra2.Text = txtPalavra2.Text.Substring(0, meio) +
            txtPalavra1.Text + txtPalavra2.Text.Substring(meio,
            txtPalavra2.Text.Length - meio);

        }

        private void btnInsere2_Click(object sender, EventArgs e)
        {
            int meio = txtPalavra1.Text.Length/2;
            txtPalavra2.Text = txtPalavra1.Text.Insert(meio, "**");

        }

        private void frm_exercicio2_Load(object sender, EventArgs e)
        {

        }
    }
}
